package com.javarush.task.task33.task3308;

import java.util.ArrayList;
import java.util.List;

public class Shop {
    public static class Goods{
        List<String> names;
    }
    public Goods goods;
    public int count;
    public double profit;
    public String[] secretData;
}
