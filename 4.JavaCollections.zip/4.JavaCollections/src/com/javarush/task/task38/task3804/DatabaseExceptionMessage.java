package com.javarush.task.task38.task3804;

public enum DatabaseExceptionMessage {
    NOT_ENOUGH_CONNECTIONS,
    NO_RESULT_DUE_TO_TIMEOUT
}
