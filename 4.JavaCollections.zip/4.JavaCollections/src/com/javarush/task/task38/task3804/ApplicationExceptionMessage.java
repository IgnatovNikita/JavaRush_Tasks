package com.javarush.task.task38.task3804;

public enum ApplicationExceptionMessage {
    UNHANDLED_EXCEPTION,
    SOCKET_IS_CLOSED
}
