package com.javarush.task.task38.task3812;

/* 
Обработка аннотаций
*/

import java.util.Arrays;

public class Solution {
    public static void main(String[] args) {
        printFullyQualifiedNames(Solution.class);
        printFullyQualifiedNames(SomeTest.class);

        printValues(Solution.class);
        printValues(SomeTest.class);
    }

    public static boolean printFullyQualifiedNames(Class c) {
        PrepareMyTest prepareMyTest;
        if (c.isAnnotationPresent(PrepareMyTest.class)){
            prepareMyTest = (PrepareMyTest) c.getAnnotation(PrepareMyTest.class);
            String[] str = prepareMyTest.fullyQualifiedNames();
            for (String s: str)
                System.out.println(s);
            return true;
        }



        return false;
    }

    public static boolean printValues(Class c) {
        PrepareMyTest prepareMyTest;
        if (c.isAnnotationPresent(PrepareMyTest.class)){
            prepareMyTest = (PrepareMyTest) c.getAnnotation(PrepareMyTest.class);
            Class<?>[] val = prepareMyTest.value();
            for (Class<?> cl: val){
                System.out.println(cl.getSimpleName());
            }

            return true;
        }
        return false;
    }
}
