package com.javarush.task.task38.task3812;

public class Fox {
    String name = "fox";
}
