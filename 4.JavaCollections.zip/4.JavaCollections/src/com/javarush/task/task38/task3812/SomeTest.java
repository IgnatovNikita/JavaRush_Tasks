package com.javarush.task.task38.task3812;

@PrepareMyTest(value = {Solution.class, SomeTest.class}, fullyQualifiedNames = {"com.javarush.task.task38.task3812.Fox"})
public class SomeTest {
}
