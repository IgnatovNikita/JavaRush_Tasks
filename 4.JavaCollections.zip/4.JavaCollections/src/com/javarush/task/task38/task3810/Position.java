package com.javarush.task.task38.task3810;

public enum Position {
    JUNIOR,
    MIDDLE,
    SENIOR,
    OTHER
}
