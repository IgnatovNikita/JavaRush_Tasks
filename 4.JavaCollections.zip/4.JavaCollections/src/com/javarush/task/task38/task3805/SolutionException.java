package com.javarush.task.task38.task3805;

public class SolutionException extends Exception {
    public SolutionException() {
        super();
    }

    public SolutionException(String message) {
        super(message);
    }
}
