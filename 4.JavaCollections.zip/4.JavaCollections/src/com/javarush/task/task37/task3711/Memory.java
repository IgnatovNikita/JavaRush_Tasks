package com.javarush.task.task37.task3711;

public class Memory {
    void allocate() {
        System.out.println("Allocating additional RAM...");
    }
}
