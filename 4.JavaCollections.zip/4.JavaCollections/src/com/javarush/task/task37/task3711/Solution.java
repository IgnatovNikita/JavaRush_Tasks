package com.javarush.task.task37.task3711;

/* 
Фасад
*/

public class Solution {
    public static void main(String[] args) {
       Computer comp = new Computer();
       comp.run();
    }
}
