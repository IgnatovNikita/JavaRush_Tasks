package com.javarush.task.task37.task3710.shapes;

public interface Shape {
    void draw();
}
