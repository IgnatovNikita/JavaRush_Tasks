package com.javarush.task.task37.task3702.male;

import com.javarush.task.task37.task3702.Human;

public class Man implements Human {
    @Override
    public String toString() {
        return "Man{}";
    }
}
