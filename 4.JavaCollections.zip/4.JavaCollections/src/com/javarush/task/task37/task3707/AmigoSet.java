package com.javarush.task.task37.task3707;

import java.io.*;
import java.util.*;

public class AmigoSet<E> extends AbstractSet<E> implements Serializable, Cloneable, Set<E> {
    private static final Object PRESENT = new Object();
    private transient HashMap<E, Object> map;

    @Override
    public boolean add(E e) {
        return map.put(e, PRESENT) == null;


    }

    @Override
    public void clear() {
        map.clear();
    }

    @Override
    public boolean isEmpty() {
        return map.isEmpty();
    }

    @Override
    public boolean contains(Object o) {
        return map.containsKey(o);
    }

    @Override
    public Object clone(){
        try{
            AmigoSet<E> newSet = (AmigoSet<E>) super.clone();
            newSet.map = (HashMap<E, Object>) map.clone();
        return newSet;
        }catch (Exception e){
            throw new InternalError();
        }
    }

    @Override
    public boolean remove(Object o) {
        return map.keySet().remove(o);
    }

    public AmigoSet(Collection<? extends E> collection){
        map = new HashMap<>((int)Math.max(16, Math.ceil(collection.size()/.75f)));
        this.addAll(collection);

    }
    public AmigoSet() {
        map = new HashMap<>();
    }

    @Override
    public Iterator iterator() {
        return map.keySet().iterator();
    }

    @Override
    public int size() {
        return map.size();
    }
    private void writeObject(ObjectOutputStream outputStream){
        try {
            outputStream.defaultWriteObject();
            //outputStream.writeObject(this);
            outputStream.writeInt(HashMapReflectionHelper.callHiddenMethod(map, "capacity"));
            outputStream.writeFloat(HashMapReflectionHelper.callHiddenMethod(map, "loadFactor"));
            outputStream.writeInt(map.size());
            for (E e: map.keySet()){
                outputStream.writeObject(e);
            }

        } catch (IOException ioException) {
            ioException.printStackTrace();

        }
    }
    private void readObject(ObjectInputStream inputStream){
        try {
            inputStream.defaultReadObject();
            int capacity = inputStream.readInt();
            float loadFactor = inputStream.readFloat();
            map = new HashMap<>(capacity, loadFactor);
            int size = inputStream.readInt();
            for (int i = 0; i < size; i++){
                map.put((E)inputStream.readObject(), PRESENT);
            }
        } catch (IOException ioException) {
            ioException.printStackTrace();
        } catch (ClassNotFoundException classNotFoundException) {
            classNotFoundException.printStackTrace();
        }
    }
}
