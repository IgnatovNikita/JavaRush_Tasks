package com.javarush.task.task37.task3708.retrievers;

public interface Retriever {
    Object retrieve(long id);
}
