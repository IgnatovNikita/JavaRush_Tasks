package com.javarush.task.task35.task3503;

public interface InterfaceForGenerics {
}
