package com.javarush.task.task35.task3507;

public interface Animal {
}
