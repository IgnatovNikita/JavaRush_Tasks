package com.javarush.task.task31.task3113;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/* 
Что внутри папки?
*/

public class Solution {
    public static class SearchFileVisitor extends SimpleFileVisitor<Path> {
        private int countDir = -1, countFiles, countMass;

        public int getCountDir() {
            return countDir;
        }

        public int getCountFiles() {
            return countFiles;
        }

        public int getCountMass() {
            return countMass;
        }

        @Override
        public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
            countDir++;
            return super.postVisitDirectory(dir, exc);
        }

        @Override
        public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {

                countFiles++;
                countMass += Files.size(file);


            return super.visitFile(file, attrs);
        }
    }
    public static void main(String[] args) throws IOException {


        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String in = br.readLine();
        br.close();

        Path path = Paths.get(in);

        if (!Files.isDirectory(path))
            System.out.println(in + " - не папка");
        else {
            SearchFileVisitor sv = new SearchFileVisitor();
            Files.walkFileTree(path, sv);
            System.out.println("Всего папок - " + sv.getCountDir());
            System.out.println("Всего файлов - " + sv.getCountFiles());
            System.out.println("Общий размер - " + sv.getCountMass());


        }
    }
}
