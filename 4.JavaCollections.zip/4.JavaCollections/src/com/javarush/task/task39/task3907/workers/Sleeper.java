package com.javarush.task.task39.task3907.workers;

public interface Sleeper {
    void sleep();
}
