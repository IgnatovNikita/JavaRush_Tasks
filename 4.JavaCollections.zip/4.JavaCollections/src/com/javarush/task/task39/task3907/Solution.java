package com.javarush.task.task39.task3907;

/* 
ISP
*/

public class Solution {
    public static void main(String[] args) {

    }
}
