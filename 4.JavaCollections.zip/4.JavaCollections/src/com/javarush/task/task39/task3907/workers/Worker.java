package com.javarush.task.task39.task3907.workers;

public interface Worker {
    void work();




}
