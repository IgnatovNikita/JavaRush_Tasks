package com.javarush.task.task39.task3908;

/* 
Возможен ли палиндром?
*/

import java.util.HashSet;
import java.util.Set;

public class Solution {
    public static void main(String[] args) {
        System.out.println(isPalindromePermutation("tanat"));
        System.out.println(isPalindromePermutation("а роза упала на лапуАзора"));
    }

    public static boolean isPalindromePermutation(String s) {
        Set<Character> set = new HashSet<>();
        char[] chars = s.toLowerCase().toCharArray();
        for (char c: chars){
            if (set.contains(c)){
                set.remove(c);
            }else
                set.add(c);
        }
        return set.size() < 2;

    }
}
