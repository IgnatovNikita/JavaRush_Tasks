package com.javarush.task.task39.task3905;

import java.util.Random;

/* 
Залей меня полностью
*/

public class Solution {
    public static void main(String[] args) {
        Color[][] image = new Color[5][5];
        for (int i = 0; i < 5; i++){
            for (int j = 0; j < 5; j++)
                image[i][j] = Color.RED;
        }

        for (int i = 1; i < 4; i++){
            for (int j = 1; j < 4; j++)
                image[i][j] = Color.BLUE;
        }
        image[1][1] = Color.INDIGO;
        image[2][3] = Color.INDIGO;
        for (int i = 0; i < 5; i++){
            for (int j = 0; j < 5; j++)
                System.out.print(image[j][i] + "\t");
            System.out.println();
        }

        PhotoPaint photoPaint = new PhotoPaint();
        photoPaint.paintFill(image, 2, 2,Color.GREEN);

        for (int i = 0; i < 5; i++){
            for (int j = 0; j < 5; j++)
                System.out.print(image[j][i] + "\t");
            System.out.println();
        }
    }
}
