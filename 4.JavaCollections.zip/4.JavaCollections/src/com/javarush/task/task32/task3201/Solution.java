package com.javarush.task.task32.task3201;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.file.Path;
import java.nio.file.Paths;

/* 
Запись в существующий файл
*/

public class Solution {
    public static void main(String... args) {
        String path = (args[0]);
        long num = new Long(args[1]);
        String text = args[2];

        try {
            RandomAccessFile raf = new RandomAccessFile(path,"rw");
            long length = raf.length();
            num = num > length ? length : num;
            raf.seek(num);
            raf.write(text.getBytes());
            raf.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
