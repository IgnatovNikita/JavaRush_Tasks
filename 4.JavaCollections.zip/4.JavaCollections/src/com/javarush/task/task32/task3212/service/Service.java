package com.javarush.task.task32.task3212.service;

public interface Service {
    String getName();

    void execute();
}