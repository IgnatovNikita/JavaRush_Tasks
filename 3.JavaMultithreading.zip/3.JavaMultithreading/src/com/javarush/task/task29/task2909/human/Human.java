package com.javarush.task.task29.task2909.human;                                                  
                                                  
import java.util.ArrayList;                                                  
import java.util.Collections;                                                  
import java.util.List;                                                  
                                                  
public class Human implements Alive {                                                  
    private static int nextId = 0;
    private int id;                                                  
    protected int age;                                                  
    protected String name;                                                  
                                                  
    private List<Human> children = new ArrayList<>();                                                  
                                                  
    protected Size size;

    public class Size {
        public int height;
        public int weight;

        public int getHeight() {
            return height;
        }

        public void setHeight(int height) {
            this.height = height;
        }

        public int getWeight() {
            return weight;
        }

        public void setWeight(int weight) {
            this.weight = weight;
        }

        public Size(int height, int weight) {
            this.height = height;
            this.weight = weight;
        }
    }
    private BloodGroup bloodGroup;
                                                  
    public void setBloodGroup(BloodGroup bl) {
        bloodGroup = bl;
       /* switch (code){
            case  1:
                bloodGroup = BloodGroup.first();
                break;
            case 2:
                bloodGroup = BloodGroup.second();
                break;
            case 3:
                bloodGroup = BloodGroup.third();
                break;
            case 4:
                bloodGroup = BloodGroup.fourth();
                break;
        }

        */

    }                                                  
                                                  
    public BloodGroup getBloodGroup() {
        return bloodGroup;
    }                                                  

    public String getPosition(){
        return "Человек";
    }
    public Human(String name, int age) {                                                  
        this.name = name;                                                  
        this.age = age;                                                  
        this.id = nextId;                                                  
        nextId++;                                                  
    }                                                  
                                                  
    public int getAge() {                                                  
        return age;                                                  
    }                                                  
                                                  
    public void setAge(int age) {                                                  
        this.age = age;                                                  
    }                                                  
                                                  
    public String getName() {                                                  
        return name;                                                  
    }                                                  
                                                  
    public void setName(String name) {                                                  
        this.name = name;                                                  
    }                                                  
                                                  
    public void live() {                                                  
    }                                                  
                                                  
    public int getId() {                                                  
        return id;                                                  
    }                                                  
                                                  

                                                  
    public List<Human> getChildren() {                                                  
        return Collections.unmodifiableList(children);                                                  
    }
    public void printData() {
        System.out.println(getPosition()+ ": " + name);
    }
    public void addChild(Human child) {                                                  
        children.add(child);                                                  
    }                                                  
                                                  
    public void removeChild(Human child) {                                                  
        children.remove(child);                                                  
    }                                                  
                                                  
    public void printSize() {                                                  
        System.out.println("Рост: " + size.height + " Вес: " + size.weight);
    }                                                  
}