package com.javarush.task.task29.task2909.human;

import java.util.ArrayList;
import java.util.List;

public class University {

    public void setStudents(List<Student> students) {
        this.students = students;
    }

    private List<Student> students = new ArrayList<>();

    private String name;
    private int age;

    public List<Student> getStudents() {
        return students;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public University(String name, int age) {

    }                                                  
                                                  
    public Student getStudentWithAverageGrade(double grade) {
        for (Student st: students) {
            if (st.getAverageGrade() == grade)
                return st;
        }
        //TODO:                                                  
        return null;                                                  
    }                                                  
                                                  
    public Student getStudentWithMaxAverageGrade() {
        //TODO:
        double max = students.get(0).getAverageGrade();
        for (Student st: students) {
            if (st.getAverageGrade() > max)
                max = st.getAverageGrade();
        }

        return getStudentWithAverageGrade(max);
    }                                                  
                                                  
   /* public void getStudentWithMinAverageGradeAndExpel() {
        //TODO:                                                  
    }

    */
    public Student getStudentWithMinAverageGrade(){
        double min = students.get(0).getAverageGrade();
        for (Student st: students) {
            if (st.getAverageGrade() < min)
                min = st.getAverageGrade();
        }

        return getStudentWithAverageGrade(min);
    }
    public void expel(Student student){
        students.remove(student);
    }
}