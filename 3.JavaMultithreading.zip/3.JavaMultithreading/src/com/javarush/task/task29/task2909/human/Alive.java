package com.javarush.task.task29.task2909.human;                                                  
                                                  
public interface Alive {                                                  
    void live();                                                  
}