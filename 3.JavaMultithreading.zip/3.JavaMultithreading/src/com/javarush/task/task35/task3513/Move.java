package com.javarush.task.task35.task3513;
@FunctionalInterface
public interface Move {
   void move();
}
