package com.javarush.task.task25.task2506;

public class LoggingStateThread extends Thread{
    Thread thread;
    State lastState;
    public LoggingStateThread(Thread thread) {
        this.thread = thread;
        this.setDaemon(true);
    }
    public void run(){
        while (thread.getState()!= State.TERMINATED) {
            if (lastState != thread.getState()) {
                System.out.println(thread.getState());
                lastState = thread.getState();
            }
        }

    }
}
