package com.javarush.task.task27.task2710;

public class Mail {
    private String text;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
