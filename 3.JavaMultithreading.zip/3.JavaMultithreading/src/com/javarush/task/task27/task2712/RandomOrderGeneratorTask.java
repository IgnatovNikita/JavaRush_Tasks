package com.javarush.task.task27.task2712;

import java.util.ArrayList;

public class RandomOrderGeneratorTask implements Runnable{
    ArrayList<Tablet> allTablets;
    @Override
    public void run() {

    }
}
