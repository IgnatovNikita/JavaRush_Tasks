package com.javarush.task.task27.task2712.ad;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StatisticAdvertisementManager {
    private static final StatisticAdvertisementManager sam = new StatisticAdvertisementManager();
    private static AdvertisementStorage as = AdvertisementStorage.getInstance();
    private StatisticAdvertisementManager(){}
    public static StatisticAdvertisementManager getInstance(){
        return sam;
    }

    public Map<String, Integer> getActiveVideoSet(){
        Map<String, Integer> res = new HashMap<>();
        ArrayList<Advertisement> list = (ArrayList<Advertisement>) as.list();

        for (Advertisement ad: list){
            if (ad.getHits() != 0){
                res.put(ad.getName(), ad.getHits());
            }
        }

        return res;
    }

    public List<String> getArchivedVideoSet(){
        List<String> res = new ArrayList<>();
        ArrayList<Advertisement> list = (ArrayList<Advertisement>) as.list();
        for (Advertisement ad: list){
            if (ad.getHits() == 0){
                res.add(ad.getName());
            }
        }
        return res;
    }
}
