package com.javarush.task.task27.task2712.statistic.event;

public enum EventType {
    COOKED_ORDER,
    SELECTED_VIDEOS,
    NO_AVAILABLE_VIDEO
}
