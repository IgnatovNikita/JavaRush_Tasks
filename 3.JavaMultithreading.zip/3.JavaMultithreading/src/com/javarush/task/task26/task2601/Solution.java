package com.javarush.task.task26.task2601;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

/* 
Почитать в инете про медиану выборки
*/

public class Solution {

    public static void main(String[] args) {
        Integer[] array = {13, 8, 15, 5, 17};
        Integer[] res = sort(array);
        //System.out.println(Arrays.toString(res));
    }

    public static Integer[] sort(Integer[] array) {
        //implement logic here
        //ArrayList newArr = new ArrayList();
        int mediana;
        Arrays.sort(array);
        if (array.length % 2 == 1)
            mediana = array[array.length / 2 ];
        else
            mediana = (array[array.length/2 - 1] + array[array.length/2]) / 2;


        Comparator<Integer> compare = new Comparator<Integer>() {

            public int compare(Integer o1, Integer o2) {
                return Math.abs(o1 - mediana) - Math.abs(o2 - mediana);
            }
        };

        Arrays.sort(array, compare);

        return array;
    }
}
