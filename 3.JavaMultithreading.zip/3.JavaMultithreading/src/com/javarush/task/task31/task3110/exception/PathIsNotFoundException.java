package com.javarush.task.task31.task3110.exception;

public class PathIsNotFoundException extends Exception {
}
