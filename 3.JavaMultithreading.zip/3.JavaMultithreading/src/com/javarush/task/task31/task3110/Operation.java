package com.javarush.task.task31.task3110;

public enum Operation {
    CREATE,
    ADD,
    REMOVE,
    EXTRACT,
    CONTENT,
    EXIT
}
