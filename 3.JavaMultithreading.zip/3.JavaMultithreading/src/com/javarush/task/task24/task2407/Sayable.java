package com.javarush.task.task24.task2407;

public interface Sayable {
    String say();
}
