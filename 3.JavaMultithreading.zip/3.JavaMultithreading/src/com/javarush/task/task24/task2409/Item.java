package com.javarush.task.task24.task2409;

public interface Item {
    int getId();
    double getPrice();
    String getTM();
}
