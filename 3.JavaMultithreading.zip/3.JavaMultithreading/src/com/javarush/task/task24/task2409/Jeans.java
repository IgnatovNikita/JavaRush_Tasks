package com.javarush.task.task24.task2409;

public interface Jeans extends Item{
    int getLength();
    int getSize();
}
