package com.javarush.task.task24.task2408;

public interface Sayable {
    String say();
}
