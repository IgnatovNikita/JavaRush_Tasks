package com.javarush.task.task24.task2404;

public interface HasWidth {
    double getWidth();
}
