package com.javarush.task.task24.task2410;

public interface Iterator {
    Iterator next();
}
