package com.javarush.task.task24.task2401;

public class UnsupportedInterfaceMarkerException extends Exception{
}
