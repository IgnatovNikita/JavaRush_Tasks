package com.javarush.task.task24.task2401;

public interface SelfInterfaceMarker {
}
