package com.javarush.task.task24.task2401;

public class SelfInterfaceMarkerImpl implements SelfInterfaceMarker{
    public void st(){}
    public void nd(){}
}
