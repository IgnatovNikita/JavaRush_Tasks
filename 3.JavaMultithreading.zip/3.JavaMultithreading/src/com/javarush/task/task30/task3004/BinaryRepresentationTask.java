package com.javarush.task.task30.task3004;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.RecursiveTask;

public class BinaryRepresentationTask extends RecursiveTask<String> {
    int x;
    public BinaryRepresentationTask(int i) {
        this.x = i;
    }

    @Override
    protected String compute() {
        int a = x % 2;
        int b = x / 2;
        String result = String.valueOf(a);
       // if (b > 0) {
         //   return binaryRepresentationMethod(b) + result;
        //}

        List<BinaryRepresentationTask> subTasks = new LinkedList<>();
        if (b > 0){
            BinaryRepresentationTask task = new BinaryRepresentationTask(b);
            task.fork(); // запустим асинхронно
            subTasks.add(task);
        }

        for(BinaryRepresentationTask task : subTasks) {
            result = task.join() + result; // дождёмся выполнения задачи и прибавим результат
        }
        return result;
    }
}
