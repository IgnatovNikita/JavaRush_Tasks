package com.javarush.task.task30.task3001;

public interface NumberSystem {
    int getNumberSystemIntValue();
}
