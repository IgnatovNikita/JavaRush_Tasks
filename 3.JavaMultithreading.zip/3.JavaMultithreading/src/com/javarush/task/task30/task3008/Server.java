package com.javarush.task.task30.task3008;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class Server {
    private static Map<String, Connection> connectionMap = new ConcurrentHashMap<>();

    private static class Handler extends Thread{
        private Socket socket;

        public Handler(Socket socket) {
            this.socket = socket;
        }

        private String serverHandshake(Connection connection) throws IOException, ClassNotFoundException{
            String name = null;
            connection.send(new Message(MessageType.NAME_REQUEST, "Введите имя пользователя"));
            Message answer = connection.receive();
            if (answer.getType() == MessageType.USER_NAME){
                name = answer.getData();

                if (name != null && !connectionMap.containsKey(name) && name.length() != 0){
                    connectionMap.put(name, connection);
                    connection.send(new Message(MessageType.NAME_ACCEPTED, "Имя принято"));

                }else {
                    name = serverHandshake(connection);
                }


            }
            else name = serverHandshake(connection);
            return name;
        }

        private void notifyUsers(Connection connection, String userName) throws IOException{
            for (String name: connectionMap.keySet()) {
                if (!name.equals(userName)){
                    Message message = new Message(MessageType.USER_ADDED, name);
                    connection.send(message);
                }

            }
        }

        private void serverMainLoop(Connection connection, String userName) throws IOException, ClassNotFoundException{
            while (true){
                Message message = connection.receive();
                if (message.getType() == MessageType.TEXT){
                    Message sendMes = new Message(MessageType.TEXT, userName + ": " + message.getData());
                    sendBroadcastMessage(sendMes);
                }else {
                    ConsoleHelper.writeMessage("Неверный тип сообщения");
                }
            }
        }

        public void run(){
            String newClient = null;

            ConsoleHelper.writeMessage("Установлено новое соединение с " + socket.getRemoteSocketAddress());
            try (Connection connection = new Connection(socket)) {
                newClient = serverHandshake(connection);
                sendBroadcastMessage(new Message(MessageType.USER_ADDED, newClient));
                notifyUsers(connection, newClient);
                serverMainLoop(connection, newClient);

            } catch (IOException | ClassNotFoundException e) {
                ConsoleHelper.writeMessage("Ошибка при обмене данными с " + socket.getRemoteSocketAddress());
            }
            if (newClient != null){
                connectionMap.remove(newClient);
                sendBroadcastMessage(new Message(MessageType.USER_REMOVED, newClient));
                ConsoleHelper.writeMessage("Соединение разорвано c " + socket.getRemoteSocketAddress());
            }


        }
    }

    public static void sendBroadcastMessage(Message message){
        for (Connection con: connectionMap.values()) {
            try {
                con.send(message);
            } catch (IOException e) {
               ConsoleHelper.writeMessage("Не удалось отправить сообщение");
            }

        }
    }
    public static void main(String[] args){
        ConsoleHelper.writeMessage("Введите порт сервера:");
        int port = ConsoleHelper.readInt();

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            ConsoleHelper.writeMessage("Чат сервер запущен.");
            while (true) {
                // Ожидаем входящее соединение и запускаем отдельный поток при его принятии
                Socket socket = serverSocket.accept();
                new Handler(socket).start();
            }
        } catch (Exception e) {
            ConsoleHelper.writeMessage("Произошла ошибка при запуске или работе сервера.");
        }
    }
}
